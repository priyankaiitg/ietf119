#author: Priyanka Sinha
#date: 18 March 2024
# Copyright (C) 2024 Priyanka Sinha
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

import pymongo

from ietfdata.datatracker   import *
from ietfdata.mailarchive2  import *
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer

import pickle

import plotly

from empath import Empath

lexicon = Empath()

dt = DataTracker()
ma = MailArchive()

ml_names = ['v6ops','6man']

ipv6 = ma.mailing_list("ipv6")
v6ops = ma.mailing_list("v6ops")

ipv6_t = ipv6.threads()
v6ops_t = v6ops.threads()

ipv6_msg_content = []
ipv6_msg_tstamps = []
ipv6_msg_cat = {}


ipv6_content = []
ipv6_tstamps = []
ipv6_cat = {}

v6ops_msg_content = []
v6ops_msg_tstamps = []
v6ops_msg_cat = {}

v6ops_tstamps = []
v6ops_content = []
v6ops_cat = {}

em_cat = ['anger','torment','ridicule','positive_emotion',
          'contentment','joy','celebration','disappointment',
          'fun','confusion','achievement','optimism','exasperation',
          'negative_emotion','politeness','irritability','negotiate',
          'fight','dispute','timidity','dominant_personality','hate',
          'trust','aggression','deception','cheerfulness']


for c in em_cat:
    ipv6_msg_cat[c] = []
    ipv6_cat[c] = []
    v6ops_cat[c] = []
    v6ops_msg_cat[c] = []
#print(v6ops_t)

for msg_id in v6ops_t:
    msg_thread = v6ops_t[msg_id]
    #print(msg_thread)
    first = msg_thread[0]
    tstamp = first.date_received()
    try:
        cstr = str(ascii((first.contents()).as_string()))
    except:
        print("bad message")
    #print(content)
    if cstr:
        mcat = lexicon.analyze(cstr, categories=em_cat)
        for c in em_cat:
            v6ops_cat[c].append(mcat[c])
        
        v6ops_tstamps.append(tstamp)
        v6ops_content.append(cstr)

    for msg in msg_thread:
        tstamp = msg.date_received()
        try:
            cstr = str(ascii((msg.contents()).as_string()))
        except:
            print("bad message")
        if cstr:
            mcat = lexicon.analyze(cstr, categories=em_cat)
            for c in em_cat:
                v6ops_msg_cat[c].append(mcat[c])
            v6ops_msg_tstamps.append(tstamp)
            v6ops_msg_content.append(cstr)

for msg_id in ipv6_t:
    msg_thread = ipv6_t[msg_id]
    #print(msg_thread)
    first = msg_thread[0]
    tstamp = first.date_received()
    try:
        cstr = str(ascii((first.contents()).as_string()))
    except:
        print("bad message")
    #print(content)
    if cstr:
        mcat = lexicon.analyze(cstr, categories=em_cat)
        for c in em_cat:
            ipv6_cat[c].append(mcat[c])
        ipv6_tstamps.append(tstamp)
        ipv6_content.append(cstr)

    for msg in msg_thread:
        tstamp = msg.date_received()
        try:
            cstr = str(ascii((msg.contents()).as_string()))
        except:
            print("bad message")
        if cstr:
            mcat = lexicon.analyze(cstr, categories=em_cat)
            for c in em_cat:
                ipv6_msg_cat[c].append(mcat[c])
            ipv6_msg_tstamps.append(tstamp)
            ipv6_msg_content.append(cstr)

ctfidf_model = ClassTfidfTransformer(reduce_frequent_words=True)
topic_model = BERTopic(ctfidf_model=ctfidf_model,verbose=True)

v6ops_topics, v6ops_probs = topic_model.fit_transform(v6ops_content)

v6ops_topics_over_time = topic_model.topics_over_time(v6ops_content, v6ops_tstamps, nr_bins=100)

pickle.dump(v6ops_content, open("v6ops_content.pkl","wb"))
pickle.dump(v6ops_tstamps,open("v6ops_tstamps.pkl","wb"))
pickle.dump(v6ops_topics_over_time,open("v6ops_topic_over_time.pkl","wb"))
pickle.dump(topic_model,open("v6ops_topic_model.pkl","wb"))

fig = topic_model.visualize_topics_over_time(v6ops_topics_over_time, top_n_topics=60)

fig.show()

v6ops_msg_topics, v6ops_msg_probs = topic_model.fit_transform(v6ops_msg_content)

v6ops_msg_topics_over_time = topic_model.topics_over_time(v6ops_msg_content, v6ops_msg_tstamps, nr_bins=100)

pickle.dump(v6ops_msg_content,open("v6ops_msg_content.pkl","wb"))
pickle.dump(v6ops_msg_tstamps,open("v6ops_msg_tstamps.pkl","wb"))
pickle.dump(v6ops_msg_topics_over_time,open("v6ops_msg_topics_over_time.pkl","wb"))
pickle.dump(topic_model,open("v6ops_msg_topic_model.pkl","wb"))

fig = topic_model.visualize_topics_over_time(v6ops_msg_topics_over_time, top_n_topics=60)

fig.show()

ipv6_topics, ipv6_probs = topic_model.fit_transform(ipv6_content)

ipv6_topics_over_time = topic_model.topics_over_time(ipv6_content, ipv6_tstamps, nr_bins=100)

pickle.dump(ipv6_content,open("ipv6_content.pkl","wb"))
pickle.dump(ipv6_tstamps,open("ipv6_tstamps.pkl","wb"))
pickle.dump(ipv6_topics_over_time,open("ipv6_topic_over_time.pkl","wb"))
pickle.dump(topic_model,open("ipv6_topic_model.pkl","wb"))

fig = topic_model.visualize_topics_over_time(ipv6_topics_over_time, top_n_topics=60)

fig.show()

ipv6_msg_topics, ipv6_msg_probs = topic_model.fit_transform(ipv6_msg_content)

ipv6_msg_topics_over_time = topic_model.topics_over_time(ipv6_msg_content, ipv6_msg_tstamps, nr_bins=100)

pickle.dump(ipv6_msg_content,open("ipv6_msg_content.pkl","wb"))
pickle.dump(ipv6_msg_tstamps,open("ipv6_msg_tstamps.pkl","wb"))
pickle.dump(ipv6_msg_topics_over_time,open("ipv6_msg_topics_over_time.pkl","wb"))
pickle.dump(topic_model,open("ipv6_msg_topic_model.pkl","wb"))

fig = topic_model.visualize_topics_over_time(ipv6_msg_topics_over_time, top_n_topics=60)

fig.show()

pickle.dump(ipv6_cat,open("ipv6_cat.pkl","wb"))
pickle.dump(ipv6_msg_cat,open("ipv6_msg_cat.pkl","wb"))
pickle.dump(v6ops_cat,open("v6ops_cat.pkl","wb"))
pickle.dump(v6ops_msg_cat,open("v6ops_msg_cat.pkl","wb"))
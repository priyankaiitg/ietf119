#author: Priyanka Sinha
#date: 18th March 2024
# Copyright (C) 2024 Priyanka Sinha
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.


import pymongo

from ietfdata.datatracker   import *
from ietfdata.mailarchive2  import *
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer

import pickle

import plotly.express as px

from empath import Empath

lexicon = Empath()

dt = DataTracker()
ma = MailArchive()

ml_names = ['v6ops','6man']

ipv6 = ma.mailing_list("ipv6")
v6ops = ma.mailing_list("v6ops")

v6ops_content = pickle.load(open("v6ops_content.pkl","rb"))
v6ops_tstamps = pickle.load(open("v6ops_tstamps.pkl","rb"))
v6ops_topic_over_time = pickle.load(open("v6ops_topic_over_time.pkl","rb"))
v6ops_topic_model = pickle.load(open("v6ops_topic_model.pkl","rb"))
v6ops_msg_cat = pickle.load(open("v6ops_msg_cat.pkl","rb"))
v6ops_cat = pickle.load(open("v6ops_cat.pkl","rb"))
v6ops_msg_topic_over_time = pickle.load(open("v6ops_msg_topics_over_time.pkl","rb"))
v6ops_msg_tstamps = pickle.load(open("v6ops_msg_tstamps.pkl","rb"))
v6ops_msg_content = pickle.load(open("v6ops_msg_content.pkl","rb"))
v6ops_msg_topic_model = pickle.load(open("v6ops_msg_topic_model.pkl","rb"))

ipv6_content = pickle.load(open("ipv6_content.pkl","rb"))
ipv6_tstamps = pickle.load(open("ipv6_tstamps.pkl","rb"))
ipv6_topic_over_time = pickle.load(open("ipv6_topic_over_time.pkl","rb"))
ipv6_topic_model = pickle.load(open("ipv6_topic_model.pkl","rb"))
ipv6_msg_cat = pickle.load(open("ipv6_msg_cat.pkl","rb"))
ipv6_cat = pickle.load(open("ipv6_cat.pkl","rb"))
ipv6_msg_topic_over_time = pickle.load(open("ipv6_msg_topics_over_time.pkl","rb"))
ipv6_msg_tstamps = pickle.load(open("ipv6_msg_tstamps.pkl","rb"))
ipv6_msg_content = pickle.load(open("ipv6_msg_content.pkl","rb"))
ipv6_msg_topic_model = pickle.load(open("ipv6_msg_topic_model.pkl","rb"))

em_cat = ['anger','torment','ridicule','positive_emotion',
          'contentment','joy','celebration','disappointment',
          'fun','confusion','achievement','optimism','exasperation',
          'negative_emotion','politeness','irritability','negotiate',
          'fight','dispute','timidity','dominant_personality','hate',
          'trust','aggression','deception','cheerfulness']


#plot overall topics over time

fig = v6ops_topic_model.visualize_topics_over_time(v6ops_topic_over_time, top_n_topics=60)

fig.show()

fig = v6ops_msg_topic_model.visualize_topics_over_time(v6ops_msg_topic_over_time, top_n_topics=60)

fig.show()

fig = ipv6_topic_model.visualize_topics_over_time(ipv6_topic_over_time, top_n_topics=60)

fig.show()

fig = ipv6_msg_topic_model.visualize_topics_over_time(ipv6_msg_topic_over_time, top_n_topics=60)

fig.show()

#plot overall empath scores
for c in em_cat:
    fig = px.line(x=v6ops_tstamps,y=v6ops_cat[c], labels={'x':'time for v6ops threads', 'y':c})

    fig.show()

for c in em_cat:
    fig = px.line(x=v6ops_msg_tstamps,y=v6ops_msg_cat[c], labels={'x':'time for v6ops messages', 'y':c})

    fig.show()

for c in em_cat:
    fig = px.line(x=ipv6_tstamps,y=ipv6_cat[c], labels={'x':'time for 6man threads', 'y':c})

    fig.show()

for c in em_cat:
    fig = px.line(x=ipv6_msg_tstamps,y=ipv6_msg_cat[c], labels={'x':'time for 6man messages', 'y':c})

    fig.show()



v6ops_to = [14,17,47,8,48,53]
v6ops_to_name = {14:'ipv6toipv4',17:'iptoip', 47:'loopback', 8:'traceroute', 48:'464xlat', 53:'ebpf'}
v6ops_msg_to = [23,32,28,59,56]
v6ops_msg_to_name = {23:'dualstacklite',32:'v6coex', 28:'icmpv6type,ip6tables,innerprefix', 59:'pointtopoint,linklocal', 56:'regulation'}
ipv6_to = [39,59,34,36]
ipv6_to_name = {39:'afrinic',59:'lpwan,6lo',34:'doh',36:'ipv4v6,vpn'}
ipv6_msg_to = [59,23,25,33]
ipv6_msg_to_name = {59:'v4only,v6only',23:'flowlabel,load balancer',25:'icmpv4v6,ipv4v6,vpn',33:'hopbyhop'}

#plot for specific topics


fig = v6ops_topic_model.visualize_topics_over_time(v6ops_topic_over_time, topics=v6ops_to)

fig.show()

fig = v6ops_msg_topic_model.visualize_topics_over_time(v6ops_msg_topic_over_time, topics=v6ops_msg_to)

fig.show()

fig = ipv6_topic_model.visualize_topics_over_time(ipv6_topic_over_time, topics=ipv6_to)

fig.show()

fig = ipv6_msg_topic_model.visualize_topics_over_time(ipv6_msg_topic_over_time, topics=ipv6_msg_to)

fig.show()

#for the topic model, for the specific topics, get the document that is closest to the topic and its timestamp, calculate the empath scores

#plot empath scores per topic


v6ops_topic_docs = v6ops_topic_model.get_document_info(v6ops_content)
v6ops_msg_topic_docs = v6ops_msg_topic_model.get_document_info(v6ops_msg_content)
ipv6_topic_docs = ipv6_topic_model.get_document_info(ipv6_content)
ipv6_msg_topic_docs = ipv6_msg_topic_model.get_document_info(ipv6_msg_content)

v6ops_topic_content = {}
v6ops_topic_tstamps = {}
v6ops_topic_cat = {}

for t_num in v6ops_to:
    v6ops_topic_content[t_num] = []
    v6ops_topic_tstamps[t_num] = []
    v6ops_topic_cat[t_num] = {}

    for c in em_cat:
        v6ops_topic_cat[t_num][c] = []

    for i in range(len(v6ops_topic_docs)):
        if bool(v6ops_topic_docs.iloc[i]['Representative_document']) and (v6ops_topic_docs.iloc[i]['Topic'] == t_num):
            v6ops_topic_content[t_num].append(v6ops_topic_docs.iloc[i]['Top_n_words'])
            v6ops_topic_tstamps[t_num].append(v6ops_tstamps[i])
            mcat = lexicon.analyze(v6ops_topic_docs.iloc[i]['Document'],categories=em_cat)
            for c in em_cat:
                v6ops_topic_cat[t_num][c].append(mcat[c])

    for c in em_cat:

        fig = px.line(x=v6ops_topic_tstamps[t_num], y=v6ops_topic_cat[t_num][c], 
                  labels={'x':'time for v6ops threads for topic '+str(v6ops_to_name[t_num]),'y':c})
        fig.show()


v6ops_msg_topic_content = {}
v6ops_msg_topic_tstamps = {}
v6ops_msg_topic_cat = {}

for t_num in v6ops_msg_to:
    v6ops_msg_topic_content[t_num] = []
    v6ops_msg_topic_tstamps[t_num] = []
    v6ops_msg_topic_cat[t_num] = {}

    for c in em_cat:
        v6ops_msg_topic_cat[t_num][c] = []

    for i in range(len(v6ops_msg_topic_docs)):
        if bool(v6ops_msg_topic_docs.iloc[i]['Representative_document']) and (v6ops_msg_topic_docs.iloc[i]['Topic'] == t_num):
            v6ops_msg_topic_content[t_num].append(v6ops_msg_topic_docs.iloc[i]['Top_n_words'])
            v6ops_msg_topic_tstamps[t_num].append(v6ops_msg_tstamps[i])
            mcat = lexicon.analyze(v6ops_msg_topic_docs.iloc[i]['Document'],categories=em_cat)
            for c in em_cat:
                v6ops_msg_topic_cat[t_num][c].append(mcat[c])

    for c in em_cat:

        fig = px.line(x=v6ops_msg_topic_tstamps[t_num], y=v6ops_msg_topic_cat[t_num][c], 
                  labels={'x':'time for v6ops messages for topic '+str(v6ops_msg_to_name[t_num]),'y':c})
        fig.show()


ipv6_topic_content = {}
ipv6_topic_tstamps = {}
ipv6_topic_cat = {}

for t_num in ipv6_to:
    ipv6_topic_content[t_num] = []
    ipv6_topic_tstamps[t_num] = []
    ipv6_topic_cat[t_num] = {}

    for c in em_cat:
        ipv6_topic_cat[t_num][c] = []

    for i in range(len(ipv6_topic_docs)):
        if bool(ipv6_topic_docs.iloc[i]['Representative_document']) and (ipv6_topic_docs.iloc[i]['Topic'] == t_num):
            ipv6_topic_content[t_num].append(ipv6_topic_docs.iloc[i]['Top_n_words'])
            ipv6_topic_tstamps[t_num].append(ipv6_tstamps[i])
            mcat = lexicon.analyze(ipv6_topic_docs.iloc[i]['Document'],categories=em_cat)
            for c in em_cat:
                ipv6_topic_cat[t_num][c].append(mcat[c])

    for c in em_cat:

        fig = px.line(x=ipv6_topic_tstamps[t_num], y=ipv6_topic_cat[t_num][c], 
                  labels={'x':'time for 6man threads for topic '+str(ipv6_to_name[t_num]),'y':c})
        fig.show()        


ipv6_msg_topic_content = {}
ipv6_msg_topic_tstamps = {}
ipv6_msg_topic_cat = {}

for t_num in ipv6_msg_to:
    ipv6_msg_topic_content[t_num] = []
    ipv6_msg_topic_tstamps[t_num] = []
    ipv6_msg_topic_cat[t_num] = {}

    for c in em_cat:
        ipv6_msg_topic_cat[t_num][c] = []

    for i in range(len(ipv6_msg_topic_docs)):
        if bool(ipv6_msg_topic_docs.iloc[i]['Representative_document']) and (ipv6_msg_topic_docs.iloc[i]['Topic'] == t_num):
            ipv6_msg_topic_content[t_num].append(ipv6_msg_topic_docs.iloc[i]['Top_n_words'])
            ipv6_msg_topic_tstamps[t_num].append(ipv6_msg_tstamps[i])
            mcat = lexicon.analyze(ipv6_msg_topic_docs.iloc[i]['Document'],categories=em_cat)
            for c in em_cat:
                ipv6_msg_topic_cat[t_num][c].append(mcat[c])

    for c in em_cat:

        fig = px.line(x=ipv6_msg_topic_tstamps[t_num], y=ipv6_msg_topic_cat[t_num][c], 
                  labels={'x':'time for 6man messages for topic '+str(ipv6_msg_to_name[t_num]),'y':c})
        fig.show()